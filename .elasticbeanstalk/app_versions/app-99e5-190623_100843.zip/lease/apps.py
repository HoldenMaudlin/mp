from django.apps import AppConfig


class LeaseConfig(AppConfig):
    name = 'lease'
