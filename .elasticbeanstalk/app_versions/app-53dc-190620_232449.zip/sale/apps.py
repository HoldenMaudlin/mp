from django.apps import AppConfig


class SaleConfig(AppConfig):
    name = 'sale'
