from django.contrib import admin
from .models import CompletedTransactions
# Register your models here.

admin.site.register(CompletedTransactions)