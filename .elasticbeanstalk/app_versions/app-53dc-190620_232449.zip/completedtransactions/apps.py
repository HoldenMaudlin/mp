from django.apps import AppConfig


class CompletedTransactionsConfig(AppConfig):
    name = 'completedtransactions'
