from django.contrib import admin
from .models import Lease
# Register your models here.

admin.site.register(Lease)